import './information/cg-help.js';
import './misc/on-all.js';
import './misc/off-all.js';
import './load/cg-rel.js';
import './load/cg-rem.js';