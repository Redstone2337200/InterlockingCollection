import { world } from "mojang-minecraft"
world.events.beforeChat.subscribe( t=> {
    world.getDimension("overworld").runCommand("function cg_unload")
})